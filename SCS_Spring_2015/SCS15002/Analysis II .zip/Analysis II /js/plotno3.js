(function($) {
    $(document).ready(function() {
	
	$('#plotno3').scianimator({
	    'images': ['autoplots/plotno31.png', 'autoplots/plotno32.png', 'autoplots/plotno33.png', 'autoplots/plotno34.png', 'autoplots/plotno35.png', 'autoplots/plotno36.png', 'autoplots/plotno37.png', 'autoplots/plotno38.png', 'autoplots/plotno39.png', 'autoplots/plotno310.png', 'autoplots/plotno311.png', 'autoplots/plotno312.png', 'autoplots/plotno313.png', 'autoplots/plotno314.png', 'autoplots/plotno315.png', 'autoplots/plotno316.png', 'autoplots/plotno317.png', 'autoplots/plotno318.png', 'autoplots/plotno319.png', 'autoplots/plotno320.png'],
	    'width': 1200,
	    'delay': 1000,
	    'loopMode': 'loop'
	});
	$('#plotno3').scianimator('play');
    });
})(jQuery);
