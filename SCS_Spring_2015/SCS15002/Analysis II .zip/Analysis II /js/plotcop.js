(function($) {
    $(document).ready(function() {
	
	$('#plotcop').scianimator({
	    'images': ['autoplots/plotcop1.png', 'autoplots/plotcop2.png', 'autoplots/plotcop3.png', 'autoplots/plotcop4.png', 'autoplots/plotcop5.png', 'autoplots/plotcop6.png', 'autoplots/plotcop7.png', 'autoplots/plotcop8.png', 'autoplots/plotcop9.png', 'autoplots/plotcop10.png', 'autoplots/plotcop11.png', 'autoplots/plotcop12.png', 'autoplots/plotcop13.png', 'autoplots/plotcop14.png', 'autoplots/plotcop15.png', 'autoplots/plotcop16.png', 'autoplots/plotcop17.png', 'autoplots/plotcop18.png', 'autoplots/plotcop19.png', 'autoplots/plotcop20.png'],
	    'width': 1200,
	    'delay': 1000,
	    'loopMode': 'loop'
	});
	$('#plotcop').scianimator('play');
    });
})(jQuery);
