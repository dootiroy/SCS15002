(function($) {
    $(document).ready(function() {
	
	$('#plottss').scianimator({
	    'images': ['autoplots/plottss1.png', 'autoplots/plottss2.png', 'autoplots/plottss3.png', 'autoplots/plottss4.png', 'autoplots/plottss5.png', 'autoplots/plottss6.png', 'autoplots/plottss7.png', 'autoplots/plottss8.png', 'autoplots/plottss9.png', 'autoplots/plottss10.png', 'autoplots/plottss11.png', 'autoplots/plottss12.png', 'autoplots/plottss13.png', 'autoplots/plottss14.png', 'autoplots/plottss15.png', 'autoplots/plottss16.png', 'autoplots/plottss17.png', 'autoplots/plottss18.png', 'autoplots/plottss19.png', 'autoplots/plottss20.png'],
	    'width': 1200,
	    'delay': 1000,
	    'loopMode': 'loop'
	});
	$('#plottss').scianimator('play');
    });
})(jQuery);
