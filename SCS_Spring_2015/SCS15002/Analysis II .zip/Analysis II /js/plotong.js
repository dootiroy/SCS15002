(function($) {
    $(document).ready(function() {
	
	$('#plotong').scianimator({
	    'images': ['autoplots/plotong1.png', 'autoplots/plotong2.png', 'autoplots/plotong3.png', 'autoplots/plotong4.png', 'autoplots/plotong5.png', 'autoplots/plotong6.png', 'autoplots/plotong7.png', 'autoplots/plotong8.png', 'autoplots/plotong9.png', 'autoplots/plotong10.png', 'autoplots/plotong11.png', 'autoplots/plotong12.png', 'autoplots/plotong13.png', 'autoplots/plotong14.png', 'autoplots/plotong15.png', 'autoplots/plotong16.png', 'autoplots/plotong17.png', 'autoplots/plotong18.png', 'autoplots/plotong19.png', 'autoplots/plotong20.png'],
	    'width': 1200,
	    'delay': 1000,
	    'loopMode': 'loop'
	});
	$('#plotong').scianimator('play');
    });
})(jQuery);
