(function($) {
    $(document).ready(function() {
	
	$('#plottkn').scianimator({
	    'images': ['autoplots/plottkn1.png', 'autoplots/plottkn2.png', 'autoplots/plottkn3.png', 'autoplots/plottkn4.png', 'autoplots/plottkn5.png', 'autoplots/plottkn6.png', 'autoplots/plottkn7.png', 'autoplots/plottkn8.png', 'autoplots/plottkn9.png', 'autoplots/plottkn10.png', 'autoplots/plottkn11.png', 'autoplots/plottkn12.png', 'autoplots/plottkn13.png', 'autoplots/plottkn14.png', 'autoplots/plottkn15.png', 'autoplots/plottkn16.png', 'autoplots/plottkn17.png', 'autoplots/plottkn18.png', 'autoplots/plottkn19.png', 'autoplots/plottkn20.png'],
	    'width': 1200,
	    'delay': 1000,
	    'loopMode': 'loop'
	});
	$('#plottkn').scianimator('play');
    });
})(jQuery);
